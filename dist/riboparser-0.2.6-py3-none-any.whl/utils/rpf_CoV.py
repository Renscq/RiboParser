#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project : riboParser
# @Script  : rpf_CoV.py


from utils.ribo import Coefficient_of_Variation

import argparse
import textwrap
from utils.ribo.ArgsParser import args_print, file_check, now_time


def rpf_cov_args_parser():
    parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description="This script is used to calculate CoV in the CDS region.",
                                     epilog=textwrap.dedent('''\
        The group file needs to contain at least two column:
        +----------+---------+
        | name     | group  |
        +==========+=========+
        | wt1      | wt      |
        | wt2      | wt      |
        | treat1   | treat   |
        | treat2   | treat   |
        | ko1      | ko      |
        | ko2      | ko      |
        +----------+---------+
    '''))

    # arguments for the Required arguments
    input_group = parser.add_argument_group('Required arguments')
    input_group.add_argument('-r', dest="rpf", required=True, type=str,
                             help="the name of input RPFs file in TXT format.")
    input_group.add_argument('-g', dest="group", required=False, type=str, default=None,
                            help="specify the list of sample group. (default: None)")
    input_group.add_argument('-l', dest="list", required=False, type=str, default=None,
                             help="the gene name list in TXT format. (default: whole).")
    input_group.add_argument('-o', dest="output", required=True, type=str,
                             help="the prefix of output file. (prefix + _Cov.txt)")

    # arguments for the CoV calculation
    parser.add_argument('-f', dest="frame", choices=['0', '1', '2', 'all'], required=False, type=str, default='all',
                        help="set the reading frame for occupancy calculation. (default: %(default)s).")
    parser.add_argument('-m', dest="min", required=False, type=int, default=5,
                        help="retain transcript with more than minimum RPFs. (default: %(default)s).")
    parser.add_argument('-n', dest="normal", action='store_true', required=False, default=False,
                        help="normalize the RPFs count to RPM. (default: %(default)s).")
    parser.add_argument('--tis', dest="tis", required=False, type=int, default=15,
                        help="The number of codons after TIS will be discarded. (default: %(default)s).")
    parser.add_argument('--tts', dest="tts", required=False, type=int, default=5,
                        help="The number of codons before TES will be discarded. (default: %(default)s).")
    parser.add_argument('--fig', dest="figure", action='store_true', required=False, default=False,
                        help="show the figure. (default: %(default)s).")
    
    args = parser.parse_args()
    file_check(args.rpf)
    args_print(args)
    return args


def main():
    now_time()
    print('\nCalculate CoV in the CDS region.', flush=True)
    print('\nStep1: Checking the input Arguments.', flush=True)
    args = rpf_cov_args_parser()
    cov = Coefficient_of_Variation.CoV(args)

    print('\nStep2: Import the RPFs file.', flush=True)
    cov.read_rpf()

    print('\nStep3: Calculate CoV.', flush=True)
    cov.cal_CoV()

    print('\nStep4: Output CoV.', flush=True)
    cov.output_CoV()

    if args.group:
        print('\nStep5: Compare CoV of each group.', flush=True)
        cov.read_group()
        cov.test_group_CoV()
    else:
        print('\nStep5: Skip CoV comparation.', flush=True)
        pass
    
    print('\nStep6: Draw CoV.', flush=True)
    cov.draw_fit_plot()

    print('\nAll done.', flush=True)
    now_time()


if __name__ == '__main__':
    main()
