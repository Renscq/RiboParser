#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project : riboParser
# @Script  : rpf_CST.py


from utils.ribo import CST

import argparse
from utils.ribo.ArgsParser import args_print, file_check, now_time


def rpf_cst_args_parser():
    parser = argparse.ArgumentParser(description="This script is used to draw the codon decoding time plot.")

    # arguments for the Required arguments
    input_group = parser.add_argument_group('Required arguments')
    input_group.add_argument('--rpf', dest="rpf", required=True, type=str,
                             help="the name of input RPFs file in TXT format.")
    input_group.add_argument('--rna', dest="rna", required=True, type=str,
                             help="the name of input reads file in TXT format.")
    input_group.add_argument('-l', dest="list", required=False, type=str, default=None,
                             help="the gene name list in TXT format. (default: whole).")
    input_group.add_argument('-o', dest="output", required=True, type=str, help="the prefix of output file.")

    # arguments for the RPFs calculation
    parser.add_argument('-s', dest="site", choices=['E', 'P', 'A'], required=False, type=str, default='P',
                        help="set the E/P/A-site for codon decoding time calculation. (default: %(default)s).")
    parser.add_argument('-f', dest="frame", choices=['0', '1', '2', 'all'], required=False, type=str, default='all',
                        help="set the reading frame for codon decoding time calculation. (default: %(default)s).")
    parser.add_argument('-m', dest="min", required=False, type=int, default=30,
                        help="retain transcript with more than minimum RPFs. (default: %(default)s).")
    parser.add_argument('-t', dest="times", required=False, type=int, default=10,
                        help="Specify the number of iteration times required for computation. (default: %(default)s).")
    parser.add_argument('--tis', dest="tis", required=False, type=int, default=0,
                        help="The number of codons after TIS will be discarded. (default: %(default)s AA).")
    parser.add_argument('--tts', dest="tts", required=False, type=int, default=0,
                        help="The number of codons before TTS will be discarded. (default: %(default)s AA).")
    parser.add_argument('--scale', dest="scale",  choices=['zscore', 'minmax'], required=False, type=str, default='minmax',
                        help="normalize the codon selection time. (default: %(default)s).")
    parser.add_argument('--stop', dest="stop",  action='store_true', required=False, default=False,
                        help="rmove the stop codon. (default: %(default)s).")
    args = parser.parse_args()
    file_check(args.rpf)
    file_check(args.rna)
    args_print(args)

    return args


def main():
    now_time()
    print('\nCalculate the codon decoding time.', flush=True)
    print('\nStep1: Checking the input Arguments.', flush=True)
    args = rpf_cst_args_parser()

    cst = CST.CodonSelectiveTime(args)

    print('\nStep2: Import the Ribo and mRNA density file.', flush=True)
    cst.import_density()

    # print('\nStep3: Combine the Ribo and mRNA density file.', flush=True)
    # cst.merge_rpf_rna()

    print('\nStep3: Calculate the codon selection time.', flush=True)
    cst.calc_cst()

    print('\nStep4: Output the codon selection time.', flush=True)
    cst.format_cst_results()
    cst.output_cst()

    print('\nStep5: Draw the codon decoding time plot.', flush=True)
    # cst.draw_cst_line()
    cst.draw_cst_corr()
    cst.draw_cst_heat()

    print('\nAll done.', flush=True)
    now_time()


if __name__ == '__main__':
    main()
