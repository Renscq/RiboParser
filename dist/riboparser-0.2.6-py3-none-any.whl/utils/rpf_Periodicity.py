#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project : riboParser
# @Script  : rpf_periodicity.py


from utils.ribo import Periodicity

import argparse
from utils.ribo.ArgsParser import args_print, file_check, now_time


def periodicity_args_parser():
    parser = argparse.ArgumentParser(description="This script is used to draw the periodicity plot.")

    # arguments for the Required arguments
    input_group = parser.add_argument_group('Required arguments')
    input_group.add_argument('-r', dest="rpf", required=True, type=str,
                             help="the name of input RPFs file in TXT format.")
    input_group.add_argument(
        '-o', dest="output", required=True, type=str,
        help="the prefix of output file."
    )

    # arguments for the ribo-seq parsing
    input_group.add_argument('-t', dest="transcript", required=False, type=str,
                             help="the name of input transcript filein TXT format.")
    parser.add_argument('-m', dest="min", required=False, type=int, default=50,
                        help="retain transcript with more than minimum RPFs. (default: %(default)s).")
    parser.add_argument('--tis', dest="tis", required=False, type=int, default=0,
                        help="the number of codons after TIS will be discarded.. (default: %(default)s AA).")
    parser.add_argument('--tts', dest="tts", required=False, type=int, default=0,
                        help="the number of codons before TTS will be discarded.. (default: %(default)s AA).")
    args = parser.parse_args()
    file_check(args.rpf)
    args_print(args)

    return args

def main():
    now_time()
    print('\nDraw the periodicity plot.', flush=True)
    print('\nStep1: Checking the input Arguments.', flush=True)
    args = periodicity_args_parser()

    print('\nStep2: Import the RPFs file.', flush=True)
    rpfs = Periodicity.Periodicity(args)
    rpfs.import_rpf()

    print('\nStep3: Calculate the 3nt periodicity.', flush=True)
    rpfs.calc_3nt_period()

    print('\nStep4: Ouput the 3nt periodicity.', flush=True)
    rpfs.output_meta()

    print('\nStep5: Draw the 3nt periodicity plot.', flush=True)
    rpfs.draw_3nt_period_count()
    rpfs.draw_3nt_period_ratio()

    print('\nAll done.', flush=True)
    now_time()


if __name__ == '__main__':
    main()
