# Author: Rensc
# date: 2026-05-21

"""
genePred parser for transcript annotation.

Supported input:
1. Basic genePred with at least 10 columns.
2. genePredExt with name2 as gene ID if available.

Coordinate convention:
- 0-based
- half-open
"""

from typing import List
from .models import Transcript


class GenePredParser:
    """
    Parse genePred annotation into Transcript objects.
    """

    @staticmethod
    def parse_int_list(value: str) -> List[int]:
        """
        Parse comma-separated integer fields from genePred.

        Parameters
        ----------
        value : str
            Comma-separated integer string.

        Returns
        -------
        list
            List of integers.
        """

        value = value.rstrip(",")

        if not value:
            return []

        return [int(x) for x in value.split(",") if x != ""]

    @staticmethod
    def read_genepred(path: str) -> List[Transcript]:
        """
        Read genePred file and return a list of Transcript objects.

        Parameters
        ----------
        path : str
            Input genePred file.

        Returns
        -------
        list
            List of Transcript objects.
        """

        transcripts = []

        with open(path, "r") as handle:
            for line in handle:
                line = line.strip()

                if not line or line.startswith("#"):
                    continue

                fields = line.split("\t")

                if len(fields) < 10:
                    raise ValueError(f"Invalid genePred line: {line}")

                transcript_id = fields[0]
                chrom = fields[1]
                strand = fields[2]
                tx_start = int(fields[3])
                tx_end = int(fields[4])
                cds_start = int(fields[5])
                cds_end = int(fields[6])
                exon_count = int(fields[7])
                exon_starts = GenePredParser.parse_int_list(fields[8])
                exon_ends = GenePredParser.parse_int_list(fields[9])

                # Validate exon structure.
                if len(exon_starts) != exon_count or len(exon_ends) != exon_count:
                    raise ValueError(f"Exon count mismatch in transcript: {transcript_id}")

                # In genePredExt, column 12 is name2, usually gene ID.
                gene_id = fields[11] if len(fields) >= 12 else transcript_id

                transcripts.append(
                    Transcript(
                        transcript_id=transcript_id,
                        chrom=chrom,
                        strand=strand,
                        tx_start=tx_start,
                        tx_end=tx_end,
                        cds_start=cds_start,
                        cds_end=cds_end,
                        exon_starts=exon_starts,
                        exon_ends=exon_ends,
                        gene_id=gene_id,
                    )
                )

        return transcripts
