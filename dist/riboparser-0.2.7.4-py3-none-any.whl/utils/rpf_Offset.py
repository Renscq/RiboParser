#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Author: Rensc; modified for improved P-site offset detection
# Version: 0.2.7-offset-enhanced
# Function: Detect P-site offset using SSCBM, RSBM, or both.

import argparse

from utils.ribo.Offset import Offset
from utils.ribo.ArgsParser import args_print, file_check, now_time


def offset_args_parser():
    parser = argparse.ArgumentParser(description="This script is used to detect the P-site offset.")

    # arguments for the Required arguments
    input_group = parser.add_argument_group('Required arguments')
    input_group.add_argument('-t', dest="transcript", required=True, type=str,
                             help="the name of input transcript filein TXT format.")
    input_group.add_argument('-b', dest="bam", required=True, type=str, help="the name of mapping file in BAM format.")
    input_group.add_argument('-o', dest="output", required=True, type=str,
                             help="the prefix of output file. (prefix + _offset.txt)")

    # arguments for the offset detection
    # parser.add_argument('--mode', dest="mode", required=False, type=str, default='SSCBM', choices=['SSCBM', 'RSBM'],
    #                     help="specify the mode of offset detect [SSCBM, RSBM]. (default: %(default)s).")
    parser.add_argument('-a', dest="align", required=False, type=str, default='both', choices=['both', 'tis', 'tts'],
                        help="specify the alignment of reads for offset detect [both, tis, tts]. (default: %(default)s).")
    parser.add_argument('-l', dest="longest", action='store_true', required=False, default=False,
                        help="only retain the transcript with longest CDS of each gene (default: %(default)s).")
    parser.add_argument('-m', dest="min", required=False, type=int, default=27,
                        help="the minimum reads length to keep (default: %(default)s nt).")
    parser.add_argument('-M', dest="max", required=False, type=int, default=33,
                        help="the maximum reads length to keep (default: %(default)s nt).")
    parser.add_argument('-p', dest="exp_peak", required=False, type=int, default=30,
                        help="Expected RPFs length fitted to ribosome structure [~30 nt] (default: %(default)s nt).")
    parser.add_argument('-s', dest="shift", required=False, type=int, default=2,
                        help="psite shift for different RPFs length. (default: %(default)s nt).")
    parser.add_argument('--silence', dest="silence", required=False, action='store_true', default=True,
                        help="discard the warning information. (default: %(default)s).")
    parser.add_argument('-d', dest="detail", action='store_true', required=False, default=False,
                        help="output the details of offset (default: %(default)s).")
    args = parser.parse_args()
    file_check(args.transcript, args.bam)
    args_print(args)

    return args


def main():
    now_time()
    print('\nDetect the p-site offset.', flush=True)
    print('\nStep1: Checking the input Arguments.', flush=True)
    args = offset_args_parser()
    offset_attr = Offset(args)

    print('\nStep2: Import the transcripts annotation.', flush=True)
    offset_attr.read_transcript()

    print('\nStep3: Import the bam file.', flush=True)
    offset_attr.get_mrna_reads()

    # if args.mode == 'SSCBM':
    print('\nStep4: Detect the SSCBM offset of sequence profile.', flush=True)
    offset_attr.get_tis_offset()
    offset_attr.adjust_tis_offset()
    offset_attr.write_tis_offset()

    offset_attr.draw_tis_heatmap()

    print('\nStep5: Detect the RSBM offset of sequence profile.', flush=True)
    offset_attr.get_frame_offset()
    offset_attr.format_frame_offset()
    offset_attr.adjust_frame_offset()
    offset_attr.write_frame_offset()

    offset_attr.draw_frame_heatmap()

    # elif args.mode == 'RSBM':
    #     print('Step4: Detect the RSBM offset of sequence profile.\n', flush=True)
    #     offset_attr.get_frame_offset()
    #     offset_attr.format_frame_offset()
    #     offset_attr.adjust_frame_offset()
    #     offset_attr.write_frame_offset()

    #     offset_attr.draw_frame_heatmap()

    now_time()
    print('\nAll done.', flush=True)


if __name__ == '__main__':
    main()
