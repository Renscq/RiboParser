#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: Rensc
# Date: 2026-07-09
# Version: 0.2.7.3
# Function: Build normalized RiboParser reference files with enhanced transcript annotation.
# Input: Genome FASTA and GTF/GFF annotation files.
# Output: Normalized genePred, GTF, enhanced norm TXT, mRNA FASTA, and CDS FASTA files.

from __future__ import annotations

import argparse
from argparse import Namespace
from collections.abc import Sequence

from utils.ribo.ArgsParser import args_print, file_check, now_time


def _build_parser() -> argparse.ArgumentParser:
    """Build the command-line argument parser."""
    parser = argparse.ArgumentParser(
        description="Build normalized RiboParser reference files."
    )

    required_group = parser.add_argument_group("Required arguments")
    required_group.add_argument(
        "-g",
        dest="genome",
        required=True,
        type=str,
        help="Input genome sequence file in FASTA format.",
    )
    required_group.add_argument(
        "-t",
        dest="gtf",
        required=True,
        type=str,
        help="Input transcript annotation file in GTF or GFF/GFF3 format.",
    )
    required_group.add_argument(
        "-o",
        dest="output",
        required=True,
        type=str,
        help="Output prefix for normalized reference files.",
    )

    parser.add_argument(
        "-u",
        dest="utr",
        required=False,
        type=int,
        default=0,
        help="Add pseudo UTR to leaderless transcripts (default: %(default)s nt).",
    )
    parser.add_argument(
        "-c",
        dest="coding",
        required=False,
        action="store_true",
        default=False,
        help="Only retain protein-coding transcripts (default: %(default)s).",
    )
    parser.add_argument(
        "-l",
        dest="longest",
        required=False,
        action="store_true",
        default=False,
        help=(
            "Only retain the representative transcript with the longest CDS per gene; "
            "recommended for subsequent analysis (default: %(default)s)."
        ),
    )
    parser.add_argument(
        "-w",
        dest="whole",
        required=False,
        action="store_true",
        default=False,
        help="Output the whole intermediate annotation table (default: %(default)s).",
    )

    return parser


def _validate_args(args: Namespace) -> None:
    """Validate command-line arguments."""
    file_check(args.genome, args.gtf)


def _parse_args(argv: Sequence[str] | None = None) -> Namespace:
    """Parse and validate command-line arguments."""
    parser = _build_parser()
    args = parser.parse_args(argv)
    _validate_args(args)
    args_print(args)
    return args


def _print_step(step: int, message: str) -> None:
    """Print a standardized pipeline step message."""
    print(f"\nStep{step}: {message}", flush=True)


def _run_reference_pipeline(args: Namespace) -> None:
    """Run the RiboParser reference-building pipeline."""
    from utils.ribo.GenePred import GenePred

    ribo_ref = GenePred(args)

    _print_step(2, "Import genome sequence.")
    ribo_ref.read_genome()

    _print_step(3, "Format GTF/GFF annotation.")
    ribo_ref.gtf2gp()
    ribo_ref.read_genepred()
    ribo_ref.get_rep_transcript()
    ribo_ref.add_utr()

    _print_step(4, "Output normalized annotation with exon blocks.")
    ribo_ref.write_txt()
    ribo_ref.gp2gtf()

    _print_step(5, "Retrieve mRNA and CDS sequences.")
    ribo_ref.get_seq()
    ribo_ref.write_seq()


def main(argv: Sequence[str] | None = None) -> None:
    """Command-line entry point for rpf_Reference."""
    args = _parse_args(argv)

    now_time()
    print("\nMake the reference for RiboParser.", flush=True)

    _run_reference_pipeline(args)

    print("\nAll done.", flush=True)
    now_time()


if __name__ == "__main__":
    main()
