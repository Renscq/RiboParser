#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: Rensc
# Date: 2026-06-12
# Version: 0.2.7
# Function: Initialize the merge_ribo package namespace.
# Input: None.
# Output: Initialized package namespace.


