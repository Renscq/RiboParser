# Author: Rensc
# date: 2026-05-21

"""
Coordinate conversion utilities for transcript-centric ORF scanning.

Main tasks:
1. Build spliced transcript sequence from genome and genePred exon blocks.
2. Convert CDS genomic coordinates into transcript coordinates.
3. Convert ORF transcript coordinates back to genomic exon blocks.
"""

from typing import Dict, List, Optional, Tuple
from .smorf_models import Transcript
from .smorf_sequence import SeqUtils


class CoordinateMapper:
    """
    Coordinate mapper between genomic space and transcript space.
    """

    @staticmethod
    def build_transcript_sequence(tx: Transcript, genome: Dict[str, str]) -> None:
        """
        Build spliced transcript sequence from genome FASTA.

        For minus-strand transcripts, exons are extracted in reverse order
        and reverse-complemented.

        Parameters
        ----------
        tx : Transcript
            Transcript object.
        genome : dict
            Genome sequence dictionary.
        """

        if tx.chrom not in genome:
            raise KeyError(f"Chromosome not found in genome FASTA: {tx.chrom}")

        chrom_seq = genome[tx.chrom]
        parts = []

        if tx.strand == "+":
            exon_iter = zip(tx.exon_starts, tx.exon_ends)

            for start, end in exon_iter:
                parts.append(chrom_seq[start:end])
        else:
            exon_iter = zip(reversed(tx.exon_starts), reversed(tx.exon_ends))

            for start, end in exon_iter:
                parts.append(SeqUtils.reverse_complement(chrom_seq[start:end]))

        tx.tx_seq = "".join(parts).upper()

        # Convert CDS genomic interval to transcript interval.
        tx.cds_tx_start, tx.cds_tx_end = CoordinateMapper.genomic_interval_to_tx_interval(
            tx,
            tx.cds_start,
            tx.cds_end,
        )

    @staticmethod
    def genomic_interval_to_tx_interval(
        tx: Transcript,
        g_start: int,
        g_end: int,
    ) -> Tuple[Optional[int], Optional[int]]:
        """
        Convert a genomic interval to transcript coordinates.

        Parameters
        ----------
        tx : Transcript
            Transcript object.
        g_start : int
            Genomic interval start.
        g_end : int
            Genomic interval end.

        Returns
        -------
        tuple
            Transcript start and end coordinates.
        """

        if g_end <= g_start:
            return None, None

        tx_ranges = []
        offset = 0

        if tx.strand == "+":
            exon_iter = list(zip(tx.exon_starts, tx.exon_ends))

            for e_start, e_end in exon_iter:
                ov_start = max(e_start, g_start)
                ov_end = min(e_end, g_end)

                if ov_start < ov_end:
                    t_start = offset + (ov_start - e_start)
                    t_end = offset + (ov_end - e_start)
                    tx_ranges.append((t_start, t_end))

                offset += e_end - e_start
        else:
            exon_iter = list(zip(reversed(tx.exon_starts), reversed(tx.exon_ends)))

            for e_start, e_end in exon_iter:
                ov_start = max(e_start, g_start)
                ov_end = min(e_end, g_end)

                if ov_start < ov_end:
                    t_start = offset + (e_end - ov_end)
                    t_end = offset + (e_end - ov_start)
                    tx_ranges.append((t_start, t_end))

                offset += e_end - e_start

        if not tx_ranges:
            return None, None

        return min(x[0] for x in tx_ranges), max(x[1] for x in tx_ranges)

    @staticmethod
    def tx_interval_to_genomic_blocks(
        tx: Transcript,
        t_start: int,
        t_end: int,
    ) -> Tuple[List[int], List[int]]:
        """
        Convert a transcript interval to genomic exon blocks.

        This function is used to map ORFs back to genePred-compatible
        genomic exon block coordinates.

        Parameters
        ----------
        tx : Transcript
            Transcript object.
        t_start : int
            Transcript interval start.
        t_end : int
            Transcript interval end.

        Returns
        -------
        tuple
            Genomic exon start list and exon end list.
        """

        blocks = []
        offset = 0

        if tx.strand == "+":
            exon_iter = list(zip(tx.exon_starts, tx.exon_ends))

            for e_start, e_end in exon_iter:
                exon_len = e_end - e_start
                seg_start = offset
                seg_end = offset + exon_len

                ov_start = max(t_start, seg_start)
                ov_end = min(t_end, seg_end)

                if ov_start < ov_end:
                    g_start = e_start + (ov_start - seg_start)
                    g_end = e_start + (ov_end - seg_start)
                    blocks.append((g_start, g_end))

                offset += exon_len
        else:
            exon_iter = list(zip(reversed(tx.exon_starts), reversed(tx.exon_ends)))

            for e_start, e_end in exon_iter:
                exon_len = e_end - e_start
                seg_start = offset
                seg_end = offset + exon_len

                ov_start = max(t_start, seg_start)
                ov_end = min(t_end, seg_end)

                if ov_start < ov_end:
                    g_start = e_end - (ov_end - seg_start)
                    g_end = e_end - (ov_start - seg_start)
                    blocks.append((g_start, g_end))

                offset += exon_len

        # genePred requires genomic blocks sorted by genomic coordinate.
        blocks = sorted(blocks, key=lambda x: x[0])

        return [x[0] for x in blocks], [x[1] for x in blocks]
