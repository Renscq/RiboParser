# Author: Rensc
# date: 2026-05-21

"""
Basic ORF filtering module.

This module filters ORFs based on rule-based criteria from ORF.message.txt.

Default reliable ORF rules:
1. Keep sense-strand ORFs.
2. Keep primary ORFs.
3. Keep complete ORFs.
4. Remove same-frame internal ORFs.
5. Remove antisense ORFs.
6. Keep selected start codons.
7. Keep ORFs within amino-acid length range.
8. Optionally require minimum Kozak score.
"""

from typing import Dict, List, Tuple


class ORFFilter:
    """
    Rule-based ORF filter.
    """

    def __init__(
        self,
        keep_start_codons: str = "ATG,CTG,GTG,TTG",
        min_aa: int = 8,
        max_aa: int = 10000,
        min_kozak_score: int = 0,
        keep_categories: str = "uORF,dORF,lncORF,iORF,emORF,overlap_uORF,overlap_dORF",
        remove_categories: str = "same_frame_iORF,antisense_ORF",
        require_sense: bool = True,
        require_primary: bool = True,
        require_complete: bool = True,
    ):
        """
        Initialize ORF filter.

        Parameters
        ----------
        keep_start_codons : str
            Comma-separated start codons to keep.
        min_aa : int
            Minimum ORF peptide length.
        max_aa : int
            Maximum ORF peptide length.
        min_kozak_score : int
            Minimum Kozak score.
        keep_categories : str
            Comma-separated ORF categories to keep.
        remove_categories : str
            Comma-separated ORF categories to remove.
        require_sense : bool
            Whether to keep only sense ORFs.
        require_primary : bool
            Whether to keep only primary ORFs.
        require_complete : bool
            Whether to keep only complete ORFs.
        """

        self.keep_start_codons = self._parse_set(keep_start_codons)
        self.min_aa = min_aa
        self.max_aa = max_aa
        self.min_kozak_score = min_kozak_score
        self.keep_categories = self._parse_set(keep_categories)
        self.remove_categories = self._parse_set(remove_categories)
        self.require_sense = require_sense
        self.require_primary = require_primary
        self.require_complete = require_complete

    @staticmethod
    def _parse_set(value: str) -> set:
        """
        Convert comma-separated string to a set.
        """

        if value is None or value == "":
            return set()

        return {x.strip() for x in value.split(",") if x.strip()}

    @staticmethod
    def read_table(path: str) -> Tuple[List[str], List[Dict[str, str]]]:
        """
        Read tab-delimited ORF message table.

        Parameters
        ----------
        path : str
            Input ORF.message.txt file.

        Returns
        -------
        tuple
            Header list and record dictionary list.
        """

        records = []

        with open(path, "r") as handle:
            header = handle.readline().rstrip("\n").split("\t")

            for line in handle:
                line = line.rstrip("\n")

                if not line:
                    continue

                fields = line.split("\t")
                record = dict(zip(header, fields))
                records.append(record)

        return header, records

    @staticmethod
    def write_table(path: str, header: List[str], records: List[Dict[str, str]]) -> None:
        """
        Write filtered ORF message table.
        """

        with open(path, "w") as out:
            out.write("\t".join(header) + "\n")

            for record in records:
                out.write("\t".join(record.get(col, "") for col in header) + "\n")

    def filter_records(
        self,
        records: List[Dict[str, str]]
    ) -> Tuple[List[Dict[str, str]], List[Dict[str, str]]]:
        """
        Filter ORF records.

        Returns
        -------
        tuple
            Passed records and removed records.
        """

        passed = []
        removed = []

        for record in records:
            keep, reason = self.check_record(record)
            record["filter_status"] = "PASS" if keep else "FAIL"
            record["filter_reason"] = reason

            if keep:
                passed.append(record)
            else:
                removed.append(record)

        return passed, removed

    def check_record(self, record: Dict[str, str]) -> Tuple[bool, str]:
        """
        Check whether one ORF record passes filters.

        Returns
        -------
        tuple
            Boolean status and filter reason.
        """

        reasons = []

        source_strand = record.get("source_strand", "")
        priority = record.get("priority", "")
        completeness = record.get("completeness", "")
        category = record.get("category", "")
        start_codon = record.get("start_codon", "")

        aa_length = self._safe_int(record.get("aa_length", "0"))
        kozak_score = self.kozak_score(record.get("kozak_seq", ""))

        if self.require_sense and source_strand != "sense":
            reasons.append("non_sense_strand")

        if self.require_primary and priority != "primary":
            reasons.append("non_primary")

        if self.require_complete and completeness != "complete":
            reasons.append("incomplete_orf")

        if self.remove_categories and category in self.remove_categories:
            reasons.append("removed_category:{}".format(category))

        if self.keep_categories and category not in self.keep_categories:
            reasons.append("category_not_allowed:{}".format(category))

        if self.keep_start_codons and start_codon not in self.keep_start_codons:
            reasons.append("start_codon_not_allowed:{}".format(start_codon))

        if aa_length < self.min_aa:
            reasons.append("too_short")

        if aa_length > self.max_aa:
            reasons.append("too_long")

        if kozak_score < self.min_kozak_score:
            reasons.append("weak_kozak")

        if reasons:
            return False, ";".join(reasons)

        return True, "PASS"

    @staticmethod
    def _safe_int(value: str) -> int:
        """
        Convert string to integer safely.
        """

        try:
            return int(value)
        except ValueError:
            return 0

    @staticmethod
    def kozak_score(kozak_seq: str) -> int:
        """
        Calculate a simple Kozak score.

        Rule:
        - Position -3 is A/G: +1
        - Position +4 is G: +1

        This assumes the default Kozak sequence format:
        6 nt upstream + 3 nt start codon + 6 nt downstream.
        """

        if not kozak_seq:
            return 0

        seq = kozak_seq.upper()
        score = 0

        # Default start codon index is 6 if full 6+3+6 sequence exists.
        start_index = 6 if len(seq) >= 9 else max(0, len(seq) // 2 - 1)

        minus3_index = start_index - 3
        plus4_index = start_index + 3

        if 0 <= minus3_index < len(seq) and seq[minus3_index] in {"A", "G"}:
            score += 1

        if 0 <= plus4_index < len(seq) and seq[plus4_index] == "G":
            score += 1

        return score

    @staticmethod
    def add_kozak_fields(header: List[str], records: List[Dict[str, str]]) -> List[str]:
        """
        Add Kozak score and Kozak level fields.
        """

        new_header = list(header)

        for col in ["kozak_score", "kozak_level", "filter_status", "filter_reason"]:
            if col not in new_header:
                new_header.append(col)

        for record in records:
            score = ORFFilter.kozak_score(record.get("kozak_seq", ""))
            record["kozak_score"] = str(score)
            record["kozak_level"] = ORFFilter.kozak_level(score)

        return new_header

    @staticmethod
    def kozak_level(score: int) -> str:
        """
        Convert Kozak score to categorical level.
        """

        if score >= 2:
            return "strong"

        if score == 1:
            return "moderate"

        return "weak"
